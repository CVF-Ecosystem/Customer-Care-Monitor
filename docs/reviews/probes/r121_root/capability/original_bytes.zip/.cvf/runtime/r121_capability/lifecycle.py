import ctypes,json,os,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
STOP=HERE/'stop_requested'
def write(name,value):
 with (HERE/name).open('x',encoding='utf-8') as f:
  json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def identity(handle):
 from ctypes import wintypes
 k=ctypes.WinDLL('kernel32',use_last_error=True)
 vals=[wintypes.FILETIME() for _ in range(4)]
 get=k.GetProcessTimes;get.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4;get.restype=wintypes.BOOL
 if not get(wintypes.HANDLE(handle),*[ctypes.byref(v) for v in vals]):raise RuntimeError('CREATION_ID_UNAVAILABLE')
 return 'windows-filetime-%016x'%((vals[0].dwHighDateTime<<32)|vals[0].dwLowDateTime)
if len(sys.argv)>1 and sys.argv[1]=='child':
 started=time.time();end=time.monotonic()+55
 write('child_started.json',{'pid':os.getpid(),'startedAt':started})
 while not STOP.exists() and time.monotonic()<end:time.sleep(.1)
 stopped=STOP.exists();write('child_end.json',{'pid':os.getpid(),'endedAt':time.time(),'stopObserved':stopped})
 sys.exit(0 if stopped else 23)
write('reservation.json',{'invocation':1,'maxSeconds':90,'declaredExit':17,'startedAt':time.time()})
p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'child'],creationflags=subprocess.CREATE_NO_WINDOW)
creation=identity(p._handle)
write('parent_ready.json',{'pid':os.getpid(),'childPid':p.pid,'childCreationIdentity':creation,'at':time.time()})
print('CAPABILITY_READY',flush=True)
try:
 code=p.wait(timeout=65)
 end=json.loads((HERE/'child_end.json').read_text())
 valid=code==0 and end.get('stopObserved') is True and end.get('pid')==p.pid
 receipt={'parentPid':os.getpid(),'childPid':p.pid,'childCreationIdentity':creation,'waitObserved':True,'childExit':code,'childEnd':end,'declaredParentExit':17,'finishedAt':time.time(),'valid':valid}
 write('parent_receipt.json',receipt);print(json.dumps(receipt),flush=True)
 sys.exit(17 if valid else 24)
except subprocess.TimeoutExpired:
 p.terminate();p.wait(timeout=5);write('timeout.json',{'childExit':p.returncode,'at':time.time()});sys.exit(25)
