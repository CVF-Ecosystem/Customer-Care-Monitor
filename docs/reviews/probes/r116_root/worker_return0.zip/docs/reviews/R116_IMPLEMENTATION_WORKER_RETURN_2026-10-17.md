# R116 implementation worker source return

Status: SOURCE_RETURN_FOR_INDEPENDENT_REVIEW / NATIVE_AND_LIVE_NOT_RUN
Tranche: CCMAI-RUNTIME-116
Role: Sol Medium IMPLEMENTATION_WORKER
Authority: immutable dispatcher seed `CVF_SESSION/authority/CCMAI-RUNTIME-116.json` at `b06209f28c36afc954f754531db6c363057d5cf7`; active R116 order and accepted R115 SPEC.

## Source delivered

- Added grant and execution rows with unique tenant/request, tenant/run, tenant/grant identities; nullable attempt execution link and case active execution/proposal pointers; migrated through ordinary `db.AutoMigrate`.
- Added strict execute POST, canonical body hash, current membership/request replay, local owner and one transaction for claim/JobRun/snapshot/grant/CAS admission. A separate committed call marker atomically debits the stable budget and creates one attempt before transport. The service is nil in ordinary routing until explicitly installed by server configuration.
- Added current permission/source checks at marker and publication, faithful usage settlement, same-case active proposal projection and immutable execution event/receipt, explicit ownerless marker observation helper, and legacy pointer uniqueness check before human proposal selection.
- Added tenant-first lineage guards on channel delete/purge, job delete/clear-runs/results and demo reset, with checked transactional deletion for results and sorted demo parent locks.
- Added new native test entrypoints for A1/A2/A3/A5/A7/A8 and selected A6 admission rollback; Root-owned fresh `r116_fixture` loopback DSN is required. The real Alibaba entrypoint requires separate Root live environment, exact endpoint hash, owner-grant/admission binding, exclusive fsynced physical effect marker, bounded request/response capture with secret guard, and a retained new fixture for independent post-child readback.

## Exact source/check evidence

The sixteen worker-edited Go paths and SHA-256 hashes immediately before final compile are in [`go5_pre_hashes.json`](probes/r116_worker/go5_pre_hashes.json). A post-compile readback matched **16/16** hashes. `git diff --check` exited 0. Go invocations **5/6** are recorded in [`go_invocations.md`](probes/r116_worker/go_invocations.md). Invocation 2 failed compile for one unused import, which was repaired; invocation 3 passed compile before native tests were added. Invocation 5 compiled engine and API handlers at the final exact source with `GOPROXY=off`, `GOSUMDB=off`, `GOTOOLCHAIN=local`, selecting zero tests; raw stdout/stderr/exit are [`go5_stdout.txt`](probes/r116_worker/go5_stdout.txt), [`go5_stderr.txt`](probes/r116_worker/go5_stderr.txt), and [`go5_exit.txt`](probes/r116_worker/go5_exit.txt). Earlier invocation outputs are honest transcriptions in the ledger, not raw captured files or retroactive source pins.

## Acceptance boundary and open findings

No DB fixture, native test, real provider call, credential read, network call, installed activation, or governance behavior assertion was performed by this worker. Native A1..A8 and live Alibaba remain **NOT_RUN** until Root's independent source/binary/fixture admission. The A3/A4 test currently changes source through a synthetic direct DB write after the marker; it does **not** prove the supported sync writer race in A4. A6 has an admission rollback discriminator and source support for explicit ownerless marker observation, but no executed crash/owner-loss or post-marker commit-fault discriminator yet. Legacy A7 tests the unique NULL-pointer candidate and new active-proposal human action; an ambiguous legacy candidate is structurally constrained by the existing unique run index and not independently proven. A8 exercises terminal published/manual-held destructive denials; simultaneous destructive races remain to be tested. These are substantive acceptance gaps for independent review, not merely skipped native invocations.

Publication now distinguishes cancellation from stale source and holds a response-recorded row on unresolved storage errors, with at most one DB-only retry by the original owner. This is source design subject to Root review, not runtime acceptance. Direct SQL/upstream history currentness, hosted CI, full M2/M3/pilot/release and R114 UI gaps stay OPEN.

## Closeability and budget recheck

Worker source edit set remains within the seed and the worker-specific evidence paths. No seed, continuity, work order, catalog, Root fixture/review, or Core edit was made. Root's separate current `IMPLEMENTATION_STATUS.json` and `r116_root`/fixture edits were not part of this worker return. Worker Go used **5/6**, fixture starts **0/1**, physical Alibaba calls **0**, native campaigns **0**, source repair rounds **0 formal reviewer rounds**. Pre-dispatch controls were Root-acknowledged; worker return fast, reviewer fast, pre-commit, runtime/live and terminal closure gates await Root review and admission. `COMPLETE_PENDING_REVIEW` and FREEZE are not asserted while the above contract gaps remain.
