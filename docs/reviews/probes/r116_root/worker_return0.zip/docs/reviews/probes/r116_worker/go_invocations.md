# R116 worker Go invocation ledger

Limit: six focused invocations. No native DB or provider execution before Root admission.

## 1 RESERVED before effect

Command: `C:/Program Files/Go/bin/gofmt.exe -w` on R116 changed Go source files. Source: current worktree, hashes recorded in final return. Stdout: empty. Stderr: empty. Exit: 0.

## 2 RESERVED before effect

Command: `go -C backend test ./engine ./api/handlers -run '^$'` with `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local`. Source: formatted worktree at invocation. Stdout: `FAIL engine [build failed]; FAIL api/handlers [build failed]`. Stderr: `engine/intervention_waitdata_executor.go:13:2: db imported and not used`. Exit: 1. No tests ran.

## 3 RESERVED before effect

Command: same offline compile-only command after first source repairs. Source: current worktree. Stdout: engine `ok [no tests to run]` 9.976s; api/handlers `ok [no tests to run]` 10.749s. Stderr: empty. Exit: 0. Native/provider tests NOT_RUN.

## 4 RESERVED before effect

Command: `C:/Program Files/Go/bin/gofmt.exe -w` on the 16 R116 changed Go paths. Exact pre-format hashes: `go4_pre_hashes.json`. Stdout: empty. Stderr: empty. Exit: 0.

## 5 RESERVED before effect

Command: `go -C backend test ./engine ./api/handlers -run '^$'`, through `run_go5.ps1`, with `GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local`. Exact pre-invocation hashes: `go5_pre_hashes.json`. Raw stdout/stderr/exit: `go5_stdout.txt`, `go5_stderr.txt`, `go5_exit.txt`. Exit: 0; engine and API handlers compiled, zero tests selected. No native/provider execution.
