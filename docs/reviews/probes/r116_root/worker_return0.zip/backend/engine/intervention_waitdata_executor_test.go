package engine

import "testing"

func TestR116ExecuteBodyHashCanonicalAndChanged(t *testing.T) {
	a := WaitDataExecuteInput{ExpectedCaseVersion: 3, GrantID: "A98E0C20-0C48-4751-A8BC-96F6DB62C762"}
	b := WaitDataExecuteInput{ExpectedCaseVersion: 3, GrantID: "a98e0c20-0c48-4751-a8bc-96f6db62c762"}
	original := HashWaitDataExecute("A98E0C20-0C48-4751-A8BC-96F6DB62C762", "63B859FC-9B3A-46C8-867C-6C582B2109D3", "61E7C7E1-0BD0-4B75-B2F6-577EC51DD7E1", a)
	canonical := HashWaitDataExecute("a98e0c20-0c48-4751-a8bc-96f6db62c762", "63b859fc-9b3a-46c8-867c-6c582b2109d3", "61e7c7e1-0bd0-4b75-b2f6-577ec51dd7e1", b)
	if original != canonical || len(original) != 64 {
		t.Fatal("canonical UUID encoding changed")
	}
	b.ExpectedCaseVersion++
	if HashWaitDataExecute("a98e0c20-0c48-4751-a8bc-96f6db62c762", "63b859fc-9b3a-46c8-867c-6c582b2109d3", "61e7c7e1-0bd0-4b75-b2f6-577ec51dd7e1", b) == canonical {
		t.Fatal("changed version replay hash unchanged")
	}
}
