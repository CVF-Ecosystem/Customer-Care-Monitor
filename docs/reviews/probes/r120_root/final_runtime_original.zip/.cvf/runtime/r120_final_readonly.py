import json,pathlib,hashlib,importlib.util,subprocess,time,re,zipfile,struct
root=pathlib.Path.cwd();out=root/'docs/reviews/probes/r120_root/final_independent'
def save(n,x):(out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
a=json.loads((root/'docs/reviews/probes/r120_root/source_binary_admission.json').read_text(encoding='utf-8-sig'));r=json.loads((root/'docs/reviews/probes/r120_root/resource_admission.json').read_text(encoding='utf-8-sig'))
spec=importlib.util.spec_from_file_location('r120_readonly',root/'scripts/r120_ui_supervisor.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
save('child_listener_observations.json',[m.host_listener_observation(a,'backend-independent',64408),m.host_listener_observation(a,'vite-independent',3019)])
ps="Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -in @(20204,21580) -or $_.Name -match '^(python|python3|handlers.test)\\.exe$' } | Select-Object ProcessId,Name,CreationDate | ConvertTo-Json -AsArray -Compress"
p=subprocess.run(['pwsh','-NoProfile','-Command',ps],capture_output=True,timeout=15);(out/'process_inventory_stdout.bin').write_bytes(p.stdout);(out/'process_inventory_stderr.bin').write_bytes(p.stderr);save('process_inventory_command.json',{'command':ps,'exit':p.returncode,'at':time.time(),'qualification':'Absence at observation does not prove original held-child wait/exit or cause'})
final=m.owner_identity(a,r);save('owned_after.json',final)
inv=m.inventory(a,r);save('protected_final.json',{'equal':inv==r['protectedBefore'],'inventory':inv,'counts':{k:len(v) for k,v in inv.items()}})
log=(root/'.cvf/runtime/r120_ui/backend.log').read_text(encoding='utf-8',errors='replace');routes=[x for x in log.splitlines() if x.startswith('R120_ROUTE ')];auth=[x for x in log.splitlines() if x.startswith('R120_AUTH_ATTEMPT ')];save('route_accounting.json',{'authAttempts':auth,'routes':routes,'authPostsObserved':len(auth),'caseMutationRouteLines':[x for x in routes if 'method=POST' in x and '/auth/' not in x],'finalDurableFingerprint':'NOT_OBSERVED','finalEffectCounters':'NOT_OBSERVED','provider0Qualification':'No provider routes admitted and no provider call observed; final durable counters missing','originalTerminal':'MISSING','serveExitReceipt':'MISSING','backendTerminalMarkers':[x for x in log.splitlines() if any(k in x for k in ['R120_FINAL','R120_EFFECT','--- PASS','--- FAIL'])]})
from PIL import Image
images=[]
for f in sorted((root/'docs/reviews/probes/r120_root/browser').glob('*.jpg')):
 with Image.open(f) as im: images.append({'path':f.relative_to(root).as_posix(),'mime':Image.MIME.get(im.format),'width':im.width,'height':im.height,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
save('native_image_manifest.json',{'originalBytes':True,'resized':False,'cssViewport390x844':'Recorded separately in browser/*.metrics.json','images':images})
checks={k:hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in a['sourceSha256'].items()};save('final_source_recheck.json',{'count':len(checks),'allEqual':all(checks.values()),'binaryEqual':hashlib.sha256((root/a['binaryPath']).read_bytes()).hexdigest()==a['binarySha256'],'executablesEqual':{n:hashlib.sha256(pathlib.Path(a[n+'Path']).read_bytes()).hexdigest()==a[n+'Sha256'] for n in ['node','docker','powershell']}})
print(json.dumps({'protectedEqual':inv==r['protectedBefore'],'authPosts':len(auth),'images':[(x['path'].split('/')[-1],x['width'],x['height']) for x in images],'sourceEqual':all(checks.values())}))
