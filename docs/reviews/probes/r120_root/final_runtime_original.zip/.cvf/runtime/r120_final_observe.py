import json, pathlib, hashlib, importlib.util, subprocess, time
root=pathlib.Path.cwd(); out=root/'docs/reviews/probes/r120_root/final_independent';out.mkdir(exist_ok=True)
def save(n,x): (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
a=json.loads((root/'docs/reviews/probes/r120_root/source_binary_admission.json').read_text(encoding='utf-8-sig'))
checks={p:hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in a['sourceSha256'].items()}
checks['binary']=hashlib.sha256((root/a['binaryPath']).read_bytes()).hexdigest()==a['binarySha256']
save('source_recheck.json',{'allEqual':all(checks.values()),'checks':checks,'observedAt':time.time()})
assert all(checks.values())
spec=importlib.util.spec_from_file_location('r120_cleanup_reference',root/'scripts/r120_ui_supervisor.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads((root/'docs/reviews/probes/r120_root/resource_admission.json').read_text(encoding='utf-8-sig'))
before=m.owner_identity(a,r);save('owned_before.json',before)
reservations=[json.loads(x) for x in (root/'.cvf/runtime/r120_ui/effect_reservations.jsonl').read_text().splitlines()]
assert not any(x.get('kind')=='docker' and x.get('args',[None])[0]=='stop' for x in reservations)
save('cleanup_reservation.json',{'purpose':'IDENTITY_PROVEN_ORPHAN_CLEANUP_ONLY_NOT_CAMPAIGN_REPLAY','fixtureStopCap':1,'priorDockerStops':0,'at':time.time(),'containerId':r['containerId'],'supervisorTerminal':'MISSING','heldChildWaitExit':'NOT_OBSERVED'})
result=m.stop_fixture(a,r)
save('orphan_cleanup_receipt.json',{'result':result,'at':time.time(),'originalSupervisorTerminal':'MISSING','claim':'Separate actual Root cleanup; never substitutes original terminal or effect fingerprint proof'})
print(json.dumps(result))

