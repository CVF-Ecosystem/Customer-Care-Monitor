from pathlib import Path
import json,os,subprocess,time
r=Path.cwd();d=r/'.cvf/runtime/review_fixes_20261018';env=dict(os.environ)
base='root:review-fix-synthetic-only@tcp(127.0.0.1:57640)/'
for key,db in {'TEST_DB_DSN':'CCMA','R101_MYSQL_DSN':'CCMA','R094_MYSQL_DSN':'CCMA','R102_MYSQL_DSN':'r102_fixture','CCMAI_R116_MYSQL_DSN':'r116_fixture'}.items():env[key]=base+db+'?charset=utf8mb4&parseTime=True&loc=UTC'
env['CCMAI_R116_NATIVE']='1'
pattern='^(TestM3ChangedSource.*|TestR101HumanWorkflowNative|TestInterventionCapabilityHonestAndSecretFree|TestR094InterventionRouteNative|TestR102NativeRevisionIntent|TestR116WaitDataNativeA7HumanAction|TestChannelSyncRunIDColumnOnFreshSchema|TestDeleteChannelRemovesResultsAndSnapshotsTogether|TestSingleAndBatchShareSnapshotContract|TestApplyPrunePlanCleansOrphanSnapshotsKeepsReferenced|TestTatS3VanDocDuocThongTinDaLuu)$'
steps=[('focused_go',['go','test','./...','-json','-count=1','-p','1','-run',pattern],r/'backend','go-focused.json'),('db_gate',['python','-B','scripts/ci_db_test_gate.py',str(d/'go-focused.json')],r,'db-gate.log'),('go_build',['go','build','./...'],r/'backend','go-build.log')]
receipt={'scope':'Focused changed-source/route/WAIT_DATA plus five required DB sentinels; NOT full Go suite','steps':[]}
for name,argv,cwd,log in steps:
 start=time.time()
 with (d/log).open('xb') as f:
  try:process=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600);code=process.returncode
  except subprocess.TimeoutExpired:code='TIMEOUT'
 receipt['steps'].append({'name':name,'argv':argv,'exit':code,'elapsedSeconds':round(time.time()-start,3),'waitObserved':code!='TIMEOUT'})
 (d/'validation_progress.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
receipt['complete']=True
(d/'validation_terminal.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
