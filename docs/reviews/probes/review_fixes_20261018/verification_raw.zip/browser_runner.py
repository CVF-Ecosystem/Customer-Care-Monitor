from pathlib import Path
import json,os,subprocess,time,sys,urllib.request,hashlib
root=Path.cwd();d=root/'.cvf/runtime/review_fixes_20261018/browser'
env=dict(os.environ)
for key in list(env):
 if key.startswith(('R095_','R096_','R098_','R100_','R116_','R119_','R120_','R121_','CCMAI_R116_')):env.pop(key,None)
env.update(REVIEW_FIX_BROWSER='1',REVIEW_FIX_DIRECTORY=str(d),R101_MYSQL_DSN='root:review-fix-synthetic-only@tcp(127.0.0.1:57640)/review_fix_ui?charset=utf8mb4&parseTime=True&loc=UTC',GIN_MODE='release')
backend=None;vite=None;result={};deadline=time.monotonic()+360
bfile=(d/'backend.log').open('xb');vfile=(d/'vite.log').open('xb')
try:
 backend=subprocess.Popen([str(root/'.cvf/runtime/review_fixes_20261018/handlers.test.exe'),'-test.run','^TestReviewFixBrowserFixture$','-test.v'],cwd=root,env=env,stdout=bfile,stderr=subprocess.STDOUT)
 print('HELD_BACKEND '+str(backend.pid),flush=True)
 while not (d/'ready.json').exists():
  if backend.poll() is not None:raise RuntimeError('backend exited before readiness')
  if time.monotonic()>deadline:raise TimeoutError('backend readiness')
  time.sleep(.2)
 manifest=json.loads((d/'ready.json').read_text())
 template=(root/'scripts/r121_vite_config.mjs.template').read_text()
 nonce='reviewfix'+str(os.getpid())
 for key,value in {'__R121_FRONTEND_ROOT__':str(root/'frontend'),'__R121_RUNTIME__':str(d),'__R121_API_ORIGIN__':manifest['apiOrigin'],'__R121_NONCE__':nonce}.items():template=template.replace(key,json.dumps(value))
 (d/'vite_config.mjs').write_text(template,encoding='utf-8')
 vite=subprocess.Popen(['node',str(root/'frontend/node_modules/vite/bin/vite.js'),'--config',str(d/'vite_config.mjs'),'--host','127.0.0.1','--port','3019','--strictPort'],cwd=root,env=env,stdout=vfile,stderr=subprocess.STDOUT)
 while True:
  if backend.poll() is not None or vite.poll() is not None:raise RuntimeError('child exited before UI ready')
  try:
   with urllib.request.urlopen('http://127.0.0.1:3019/__r121_health',timeout=2) as response:
    if response.read().decode()==nonce:break
  except OSError:pass
  if time.monotonic()>deadline:raise TimeoutError('UI readiness')
  time.sleep(.2)
 (d/'ui_ready.json').write_text(json.dumps({'uiOrigin':'http://127.0.0.1:3019','backendPid':backend.pid,'vitePid':vite.pid,'manifest':manifest}),encoding='utf-8')
 print('UI_READY',flush=True)
 while not (d/'stop').exists():
  if backend.poll() is not None or vite.poll() is not None:raise RuntimeError('child exited during UI')
  if time.monotonic()>deadline:raise TimeoutError('UI deadline')
  time.sleep(.2)
except Exception as exc:result['error']=type(exc).__name__+':'+str(exc)
finally:
 (d/'stop').touch(exist_ok=True)
 if backend is not None:
  try:result['backendExit']=backend.wait(timeout=15);result['backendWaitObserved']=True
  except subprocess.TimeoutExpired:backend.terminate();result['backendExit']=backend.wait(timeout=10);result['backendWaitObserved']=True;result['backendForced']=True
 if vite is not None:
  if vite.poll() is None:vite.terminate()
  result['viteExit']=vite.wait(timeout=10);result['viteWaitObserved']=True
 bfile.close();vfile.close()
 (d/'wrapper_terminal.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print('WRAPPER_TERMINAL '+json.dumps(result),flush=True)
sys.exit(0 if result.get('backendExit')==0 and 'error' not in result and not result.get('backendForced') else 1)
