# R115 documentary design worker return

Status: COMPLETE_PENDING_REVIEW
Risk: R1
Worker: /root/r115_executor_spec
Reviewer: Codex /root
Commit steward: Codex /root

Delivered: source-backed [executor SPEC](../specs/M3_WAITDATA_EXECUTOR_R115_SPEC_2026-10-17.md), [non-dispatchable R2 candidate packet](planning/R115_EXECUTOR_IMPLEMENTATION_WORK_ORDER_DRAFT_2026-10-17.md), and [source identity ledger](probes/r115_worker/source_identity.json). Inspected product baseline `68a3d30b921c3c145659c187daa1cecb49fe50d8` separately from current HEAD `4aa2e49354be162e080a0f7d6305a1e749b73ce2`. Original R102 request/revision behavior is a source fact; execution/claim/active projection are intended behavior only. No product source, tests, authority seed, continuity/catalog or old record changed by worker.

Repair round 1 after Root's consolidated D01–D04 review: specified a new transaction-aware coordinator primitive with authorization, one claim and one JobRun in one durable admission; replay/loser creates no run or debit. Added MySQL case-pointer CAS, exact proposed route/body/status/grant boundary, pre-call marker and manual hold for uncertain commit/call; corrected destructive-writer locks and provenance preservation; resolved actual `backend/db/mysql.go`/`backend/api/router.go` paths and future fixture lifecycle budget. Source ledger extended to these inspected files. Root review finding is preserved at `R115_CONSOLIDATED_DESIGN_REVIEW_ROUND0_2026-10-17.md`; acceptance remains pending re-review.

Key design decision: a fresh, server-bound execution grant and current permission/source checks precede one claimed call. Existing `ReserveJobRun` persists its own running row; the proposed **new** coordinator admission combines claim and JobRun in one short transaction. Publication advances the *same* case to a reviewable active proposal, keeps original history/snapshot/revision/request immutable, and rechecks source under supported writer locks. A call with unknown outcome retains its debit and requires operator disposition; R102 cannot automatically issue a replacement request for the unchanged source/revision. No exactly-once external-effect claim.

Closeability recheck after repair 1: the documentary gate-to-role topology in the active R1 order remains applicable; added source reads and future candidate paths stay inside this documentary packet, while any product edit still needs a new R2 seed. Root reviewer must recheck D01–D04, pins, current/proposed distinctions, destructive-writer coverage and A1–A8 before accepting. Future implementation needs a separately committed dispatcher seed, executable budget/provider grant, capability and terminal receipts, and independent reviewer. Present worker return is **not** self-review or FREEZE.

Evidence limits: workspace doctor 27/27 with manifest-pin warning; canonical Core knowledge ingest one local README chunk; source reads only. Product tests, Go/native/Node, DB, browser, Docker, provider/network/credential access and runtime AI governance proof: NOT_RUN. Inherited R102 exact-revision tests were read as source context, not rerun. R114 remains CHANGES_REQUIRED with terminal/cleanup gap, B08 raster qualified and B09 unsupported. Full M2/M3, pilot/release and account setup remain open.
