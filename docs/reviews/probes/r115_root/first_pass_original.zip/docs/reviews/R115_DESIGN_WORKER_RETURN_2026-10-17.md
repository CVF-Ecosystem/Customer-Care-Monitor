# R115 documentary design worker return

Status: COMPLETE_PENDING_REVIEW
Risk: R1
Worker: /root/r115_executor_spec
Reviewer: Codex /root
Commit steward: Codex /root

Delivered: source-backed [executor SPEC](../specs/M3_WAITDATA_EXECUTOR_R115_SPEC_2026-10-17.md), [non-dispatchable R2 candidate packet](planning/R115_EXECUTOR_IMPLEMENTATION_WORK_ORDER_DRAFT_2026-10-17.md), and [source identity ledger](probes/r115_worker/source_identity.json). Inspected product baseline `68a3d30b921c3c145659c187daa1cecb49fe50d8` separately from current HEAD `4aa2e49354be162e080a0f7d6305a1e749b73ce2`. Original R102 request/revision behavior is a source fact; execution/claim/active projection are intended behavior only. No product source, tests, authority seed, continuity/catalog or old record changed by worker.

Key design decision: a fresh, server-bound execution grant and current permission/source checks precede one claimed call. The existing `ReserveJobRun` persists its own running row, so the subsequent claim is a distinct transaction with orphan handling. Publication advances the *same* case to a reviewable active proposal, keeps original history/snapshot/revision/request immutable, and rechecks source under supported writer locks. A call with unknown outcome retains its debit and requires operator disposition; no automatic replay or exactly-once external-effect claim.

Closeability recheck at return: the documentary gate-to-role topology in the active order remains applicable and no new dependency/path class was discovered for this R1 packet. Root reviewer must verify pins, citation ranges, current/proposed distinctions, source-writer coverage, candidate-path specificity and A1–A8 before accepting. Future R2 implementation needs a new dispatcher seed, executable budget/provider grant, actual migration/route path confirmation and independent reviewer. Present worker return is **not** self-review or FREEZE.

Evidence limits: workspace doctor 27/27 with manifest-pin warning; canonical Core knowledge ingest one local README chunk; source reads only. Product tests, Go/native/Node, DB, browser, Docker, provider/network/credential access and runtime AI governance proof: NOT_RUN. Inherited R102 exact-revision tests were read as source context, not rerun. R114 remains CHANGES_REQUIRED with terminal/cleanup gap, B08 raster qualified and B09 unsupported. Full M2/M3, pilot/release and account setup remain open.
