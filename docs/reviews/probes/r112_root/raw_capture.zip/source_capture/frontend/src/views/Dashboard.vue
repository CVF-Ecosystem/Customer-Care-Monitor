<template>
  <div>
    <!-- Demo Import Banner -->
    <v-alert v-if="demoStatus && !demoStatus.has_data" type="info" variant="tonal" class="mb-4" prominent>
      <div>
        <div class="text-subtitle-1 font-weight-bold mb-1">Chào mừng! Bắt đầu với dữ liệu demo</div>
        <div class="text-body-2 mb-3">Hệ thống chưa có dữ liệu. Nhập dữ liệu demo để trải nghiệm cách AI đánh giá chất lượng CSKH và phân loại cuộc chat. Dữ liệu mẫu chỉ dùng để thử tính năng.</div>
        <v-btn color="primary" variant="flat" :loading="importingDemo" @click="importDemo">
          <v-icon start>mdi-database-import</v-icon>
          Nhập dữ liệu demo
        </v-btn>
      </div>
    </v-alert>

    <!-- Demo Reset Banner -->
    <v-alert v-if="demoStatus && demoStatus.is_demo" type="warning" variant="tonal" class="mb-4" density="compact">
      <div class="d-flex align-center">
        <v-icon start size="small">mdi-information</v-icon>
        <span class="text-body-2 flex-grow-1">Bạn đang sử dụng dữ liệu demo. Khi sẵn sàng, hãy xóa để bắt đầu với dữ liệu thật.</span>
        <v-btn color="error" variant="text" size="small" @click="resetDialog = true">
          <v-icon start size="small">mdi-delete</v-icon>
          Xóa dữ liệu demo
        </v-btn>
      </div>
    </v-alert>

    <!-- Reset confirm dialog -->
    <v-dialog v-model="resetDialog" max-width="480">
      <v-card>
        <v-card-title class="text-error">Xóa toàn bộ dữ liệu demo</v-card-title>
        <v-card-text>
          <v-alert type="error" variant="tonal" class="mb-3">
            Tất cả dữ liệu sẽ bị xóa bao gồm: kênh chat, tin nhắn, công việc, kết quả đánh giá, nhật ký chi phí. Chỉ giữ lại danh sách thành viên.
          </v-alert>
          <div class="text-body-2">Hành động này không thể hoàn tác. Bạn có chắc chắn?</div>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn variant="text" @click="resetDialog = false">Hủy</v-btn>
          <v-btn color="error" variant="flat" :loading="resettingDemo" @click="resetDemo">Xóa tất cả</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <div class="d-flex flex-wrap align-center mb-4 ga-2">
      <h1 class="text-h5 font-weight-bold d-none d-md-block">{{ $t('dashboard') }}</h1>
      <v-spacer class="d-none d-md-block" />
      <v-chip-group v-model="datePreset">
        <v-chip v-for="p in datePresets" :key="p.value" :value="p.value" size="small" variant="outlined" @click="applyPreset(p.value)">
          {{ p.label }}
        </v-chip>
      </v-chip-group>
      <!-- Desktop: inline with chips -->
      <v-text-field v-model="dateFrom" type="date" density="compact" hide-details style="max-width: 160px" class="d-none d-md-block" @change="loadDashboard" />
      <v-text-field v-model="dateTo" type="date" density="compact" hide-details style="max-width: 160px" class="d-none d-md-block" @change="loadDashboard" />
      <span class="text-caption text-medium-emphasis" data-testid="vn-date-note">{{ $t('vn_date_note') }}</span>
    </div>
    <!-- Mobile: separate row -->
    <v-row dense class="mb-4 d-md-none">
      <v-col cols="6">
        <v-text-field v-model="dateFrom" type="date" density="compact" hide-details @change="loadDashboard" />
      </v-col>
      <v-col cols="6">
        <v-text-field v-model="dateTo" type="date" density="compact" hide-details @change="loadDashboard" />
      </v-col>
    </v-row>

    <!-- Stat cards -->
    <v-row v-if="visibleStats.length" class="mb-6">
      <v-col v-for="stat in visibleStats" :key="stat.label" cols="6" sm="4" md="3">
        <v-card class="pa-4">
          <div class="d-flex justify-space-between align-center">
            <div>
              <div class="text-body-2 text-grey" :title="stat.hint ? $t(stat.hint) : undefined">{{ $t(stat.label) }}</div>
              <div class="text-h5 font-weight-bold mt-1">{{ stat.value }}</div>
            </div>
            <v-icon :color="stat.color" size="32" class="opacity-50">{{ stat.icon }}</v-icon>
          </div>
        </v-card>
      </v-col>
    </v-row>

    <!-- Message projection -->
    <v-row v-if="canViewDashboard('messages')" class="mb-4" data-testid="dashboard-messages-section">
      <v-col v-for="ch in channelCounts" :key="ch.channel_type" cols="6" sm="3" data-testid="dashboard-messages-channel-breakdown">
        <v-card class="pa-4">
          <div class="d-flex justify-space-between align-center">
            <div>
              <div class="text-body-2 text-grey">{{ channelTypeInfo(ch.channel_type).label }}</div>
              <div class="text-h5 font-weight-bold mt-1">{{ ch.count }}</div>
            </div>
            <v-icon :color="channelTypeInfo(ch.channel_type).color" size="32" class="opacity-50">
              {{ channelTypeInfo(ch.channel_type).icon }}
            </v-icon>
          </div>
        </v-card>
      </v-col>
      <v-col cols="6" sm="3">
        <v-card class="pa-4">
          <div class="d-flex justify-space-between align-center">
            <div>
              <div class="text-body-2 text-grey">Tổng tin nhắn</div>
              <div class="text-h5 font-weight-bold mt-1">{{ totalMessages.toLocaleString() }}</div>
            </div>
            <v-icon color="primary" size="32" class="opacity-50">mdi-email-multiple</v-icon>
          </div>
        </v-card>
      </v-col>
    </v-row>

    <!-- Settings projection -->
    <v-row v-if="canViewDashboard('settings')" class="mb-4" data-testid="dashboard-settings-section">
      <v-col cols="6" sm="3">
        <v-card class="pa-4">
          <div class="d-flex justify-space-between align-center">
            <div>
              <div class="text-body-2 text-grey">{{ $t('ai_cost') }}</div>
              <div class="text-h5 font-weight-bold mt-1">{{ Math.round(costPeriod * exchangeRate).toLocaleString('vi-VN') }}đ</div>
            </div>
            <v-icon color="warning" size="32" class="opacity-50">mdi-currency-usd</v-icon>
          </div>
        </v-card>
      </v-col>
    </v-row>

    <v-row>
      <!-- Recent Activity (QC + Classification mixed) -->
      <v-col v-if="canViewDashboard('jobs')" cols="12" md="7" data-testid="dashboard-jobs-section">
        <v-card class="pa-4">
          <div class="text-subtitle-1 font-weight-bold mb-3">
            <v-icon start size="small" color="primary">mdi-bell-ring</v-icon>
            Hoạt động gần đây
          </div>
          <div v-if="recentActivity.length">
            <div
              v-for="item in recentActivity"
              :key="item.id"
              class="d-flex align-center pa-2 mb-1 rounded"
              style="cursor: pointer"
              :style="{ background: item._type === 'qc'
                ? 'rgba(var(--v-theme-error), 0.08)'
                : 'rgba(var(--v-theme-on-surface), 0.04)' }"
              @click="goToConversation(item.conversation_id, item._type === 'qc' ? 'evaluation' : 'classification')"
            >
              <!-- QC Alert row -->
              <template v-if="item._type === 'qc'">
                <v-chip size="x-small" :color="item.severity === 'NGHIEM_TRONG' ? 'error' : 'warning'" variant="tonal" class="mr-2 flex-shrink-0">
                  {{ item.severity === 'NGHIEM_TRONG' ? 'Nghiêm trọng' : 'Cần cải thiện' }}
                </v-chip>
                <span class="text-body-2 flex-grow-1" style="overflow: hidden; white-space: nowrap; text-overflow: ellipsis;">{{ item.evidence || item.rule_name }}</span>
              </template>
              <!-- Classification row -->
              <template v-else>
                <span class="text-body-2 font-weight-medium mr-2 flex-shrink-0">{{ item.customer_name || '—' }}</span>
                <span class="text-body-2 text-grey-darken-1 mr-2 flex-shrink-0">Phân loại:</span>
                <v-chip size="x-small" color="deep-purple" variant="tonal" class="mr-1 flex-shrink-0">{{ item.rule_name }}</v-chip>
              </template>
              <v-spacer />
              <span class="text-caption text-grey text-no-wrap ml-2">{{ timeAgo(item.created_at) }}</span>
            </div>
          </div>
          <div v-else class="text-center pa-6">
            <v-icon size="40" color="success" class="mb-2">mdi-check-circle</v-icon>
            <div class="text-grey">Chưa có hoạt động nào trong khoảng thời gian này.</div>
          </div>
        </v-card>
      </v-col>

      <!-- AI Cost + Service Status -->
      <v-col cols="12" md="5">
        <!-- AI Cost Summary -->
        <v-card v-if="canViewDashboard('settings')" class="pa-4 mb-4" data-testid="dashboard-settings-cost-summary">
          <div class="text-subtitle-1 font-weight-bold mb-3">
            <v-icon start size="small" color="warning">mdi-currency-usd</v-icon>
            {{ $t('ai_cost') }}
          </div>
          <div class="d-flex ga-4 mb-3">
            <div>
              <div class="text-caption text-grey">{{ $t('cost_today') }}</div>
              <div class="text-h6 font-weight-bold">{{ Math.round(costToday * exchangeRate).toLocaleString('vi-VN') }}đ</div>
            </div>
            <div>
              <div class="text-caption text-grey">{{ $t('cost_this_month') }}</div>
              <div class="text-h6 font-weight-bold">{{ Math.round(costMonth * exchangeRate).toLocaleString('vi-VN') }}đ</div>
            </div>
          </div>

          <!-- Cost by day table -->
          <v-table v-if="costByDay.length" density="compact" class="text-body-2">
            <thead>
              <tr>
                <th>{{ $t('date') }}</th>
                <th class="text-right">Tokens</th>
                <th class="text-right">{{ $t('cost') }} (VNĐ)</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="day in costByDay.slice(0, 7)" :key="day.date">
                <td>{{ formatDisplayDate(day.date) }}</td>
                <td class="text-right text-caption">{{ (day.input_tokens + day.output_tokens).toLocaleString() }}</td>
                <td class="text-right">{{ Math.round(day.total_cost * exchangeRate).toLocaleString('vi-VN') }}đ</td>
              </tr>
            </tbody>
          </v-table>
          <div v-else class="text-center text-grey text-caption pa-2">{{ $t('no_data') }}</div>
        </v-card>

        <!-- Service Status -->
        <!-- CCMAI-RUNTIME-029 (F07): there is no health check behind these rows, so the card states
             that explicitly. The rows are neutral and independent of the Dashboard request. -->
        <v-card class="pa-4" data-testid="service-status-card">
          <div class="text-subtitle-1 font-weight-bold mb-1">
            <v-icon start size="small" aria-hidden="true">mdi-help-circle-outline</v-icon>
            {{ $t('service_status') }}
          </div>
          <div class="text-caption text-medium-emphasis mb-2" data-testid="service-status-note">{{ $t('service_health_note') }}</div>
          <v-list density="compact">
            <v-list-item v-for="name in serviceNames" :key="name" class="px-0">
              <v-list-item-title class="text-body-2">{{ $t(name) }}</v-list-item-title>
              <template #append>
                <v-chip size="x-small" variant="tonal" prepend-icon="mdi-help-circle-outline" data-testid="service-status-chip">
                  {{ $t('service_health_unknown') }}
                </v-chip>
              </template>
            </v-list-item>
          </v-list>
        </v-card>
      </v-col>
    </v-row>

    <!-- Charts Row -->
    <v-row v-if="canViewDashboard('messages') || canViewDashboard('settings')" class="mt-4">
      <v-col v-if="canViewDashboard('messages')" cols="12" md="6" data-testid="dashboard-messages-chart-section">
        <v-card class="pa-4">
          <div class="text-subtitle-1 font-weight-bold mb-3">
            <v-icon start size="small" color="primary">mdi-message-text-clock</v-icon>
            {{ $t('messages_by_day') }}
          </div>
          <Line v-if="messagesChartData.labels.length" :data="messagesChartData" :options="chartOptions" style="max-height: 250px" />
          <div v-else class="text-center text-grey pa-4">{{ $t('no_data') }}</div>
        </v-card>
      </v-col>
      <v-col v-if="canViewDashboard('settings')" cols="12" md="6" data-testid="dashboard-settings-chart-section">
        <v-card class="pa-4">
          <div class="text-subtitle-1 font-weight-bold mb-3">
            <v-icon start size="small" color="warning">mdi-chart-line</v-icon>
            {{ $t('cost_by_day_chart') }}
          </div>
          <Line v-if="costChartData.labels.length" :data="costChartData" :options="chartOptionsNoLegend" style="max-height: 250px" />
          <div v-else class="text-center text-grey pa-4">{{ $t('no_data') }}</div>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script setup lang="ts">
import { channelTypeInfo } from '../composables/channelTypes'
import { ref, computed, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Line } from 'vue-chartjs'
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Filler, Legend } from 'chart.js'
import api from '../api'
import { useI18n } from 'vue-i18n'
import { formatRelative, type UiLocale } from '../utils/format'
import { presetRange, type DatePreset } from '../utils/businessDay'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Filler, Legend)

const route = useRoute()
const router = useRouter()
const tenantId = computed(() => route.params.tenantId as string)

const stats = ref([
  { label: 'total_conversations', resource: 'messages', value: 0, icon: 'mdi-message-text', color: 'primary' },
  { label: 'dash_qc_violations', hint: 'dash_qc_violations_hint', resource: 'jobs', value: '—' as string | number, icon: 'mdi-clipboard-check-outline', color: 'error' },
  { label: 'active_jobs', resource: 'jobs', value: 0, icon: 'mdi-briefcase-check', color: 'success' },
  { label: 'active_channels', resource: 'channels', value: 0, icon: 'mdi-connection', color: 'info' },
])

const dashboardRole = ref('')
const dashboardPermissions = ref<Record<string, string>>({})
const dashboardPermissionsReady = ref(false)
function canViewDashboard(resource: string): boolean {
  if (dashboardRole.value === 'owner' || dashboardRole.value === 'admin') return true
  if (dashboardRole.value !== 'member') return false
  const permission = dashboardPermissions.value[resource]
  return typeof permission === 'string' && permission.includes('r')
}
const visibleStats = computed(() => stats.value.filter(stat => canViewDashboard(stat.resource)))
function hasDashboardReadAccess(): boolean {
  return ['channels', 'messages', 'jobs', 'settings'].some(canViewDashboard)
}

const qcAlerts = ref<any[]>([])
const classRecent = ref<any[]>([])

const recentActivity = computed(() => {
  const qc = qcAlerts.value.map(a => ({ ...a, _type: 'qc' }))
  const cls = classRecent.value.map(a => ({ ...a, _type: 'class' }))
  return [...qc, ...cls]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 10)
})

const costPeriod = ref(0)
const costToday = ref(0)
const costMonth = ref(0)
const costByDay = ref<any[]>([])
const exchangeRate = ref(26000)
// Service names only: no health state exists in the UI (CCMAI-RUNTIME-029). Health is neither
// inferred from the Dashboard request nor from job/channel counts or payload hints.
const serviceNames = ['service_application', 'service_data_storage', 'service_automated_schedule']
const messagesByDay = ref<any[]>([])
const channelCounts = ref<any[]>([])
const totalMessages = computed(() => messagesByDay.value.reduce((sum, d) => sum + (d.count || 0), 0))

// Date filter + presets
// CCMAI-RUNTIME-026: dates are Vietnam calendar dates (UTC+7), independent of the browser zone.
const initialRange = presetRange('28days')
const dateFrom = ref(initialRange.from)
const dateTo = ref(initialRange.to)
const datePreset = ref('28days')

const datePresets = [
  { label: 'Hôm nay', value: 'today' },
  { label: '7 ngày', value: '7days' },
  { label: '28 ngày', value: '28days' },
  { label: 'Tháng này', value: 'month' },
  { label: 'Quý này', value: 'quarter' },
  { label: 'Năm này', value: 'year' },
]

function applyPreset(preset: string) {
  const range = presetRange(preset as DatePreset)
  dateFrom.value = range.from
  dateTo.value = range.to
  loadDashboard()
}

function formatDisplayDate(dateStr: string) {
  if (!dateStr) return ''
  // Handle "2026-03-21" or "2026-03-21T00:00:00Z"
  const parts = dateStr.split('T')[0].split('-')
  if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`
  return dateStr
}

function formatChartDate(dateStr: string) {
  if (!dateStr) return ''
  const parts = dateStr.split('T')[0].split('-')
  if (parts.length === 3) return `${parseInt(parts[2])}/${parseInt(parts[1])}`
  return dateStr
}

const messagesChartData = computed(() => ({
  labels: messagesByDay.value.map(d => formatChartDate(d.date)),
  datasets: [
    {
      label: 'Tổng tin nhắn',
      data: messagesByDay.value.map(d => d.count),
      borderColor: '#5C6BC0',
      backgroundColor: 'rgba(92,107,192,0.1)',
      fill: false,
      tension: 0.3,
    },
    {
      label: 'Cuộc chat',
      data: messagesByDay.value.map(d => d.chat_count || 0),
      borderColor: '#66BB6A',
      fill: false,
      tension: 0.3,
    },
    {
      label: 'Trả lời NV',
      data: messagesByDay.value.map(d => d.reply_count || 0),
      borderColor: '#FFA726',
      fill: false,
      tension: 0.3,
    },
  ],
}))

const costChartData = computed(() => ({
  labels: [...costByDay.value].reverse().map(d => formatChartDate(d.date)),
  datasets: [{
    label: 'Chi phí (VNĐ)',
    data: [...costByDay.value].reverse().map(d => Math.round(d.total_cost * exchangeRate.value)),
    borderColor: '#FFA726',
    backgroundColor: 'rgba(255,167,38,0.1)',
    fill: true,
    tension: 0.3,
  }],
}))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: true, position: 'bottom' as const } },
  scales: { y: { beginAtZero: true } },
}

const chartOptionsNoLegend = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: false } },
  scales: { y: { beginAtZero: true } },
}

let dashboardRequestId = 0
let permissionRequestId = 0
let demoStatusRequestId = 0
function clearDashboardData() {
  stats.value[0].value = 0
  stats.value[1].value = '—'
  stats.value[2].value = 0
  stats.value[3].value = 0
  qcAlerts.value = []
  classRecent.value = []
  costPeriod.value = 0
  costToday.value = 0
  costMonth.value = 0
  costByDay.value = []
  exchangeRate.value = 26000
  messagesByDay.value = []
  channelCounts.value = []
}

async function loadDashboard() {
  const requestId = ++dashboardRequestId
  const requestTenantId = tenantId.value
  if (!requestTenantId || !dashboardPermissionsReady.value || !hasDashboardReadAccess()) return
  stats.value[1].value = '—'
  try {
    const params: Record<string, string> = {}
    if (dateFrom.value) params.from = dateFrom.value
    if (dateTo.value) params.to = dateTo.value

    const { data } = await api.get(`/tenants/${requestTenantId}/dashboard`, { params })
    if (requestId !== dashboardRequestId || requestTenantId !== tenantId.value) return
    if (canViewDashboard('messages')) {
      stats.value[0].value = data.total_conversations ?? 0
      messagesByDay.value = data.messages_by_day || []
      channelCounts.value = data.conversations_by_channel || []
    }
    if (canViewDashboard('jobs')) {
      const qcCount = data.qc_violation_count
      stats.value[1].value = Number.isSafeInteger(qcCount) && qcCount >= 0 ? qcCount : '—'
      stats.value[2].value = data.active_jobs ?? 0
      qcAlerts.value = data.qc_alerts || []
      classRecent.value = data.classification_recent || []
    }
    if (canViewDashboard('channels')) {
      stats.value[3].value = data.active_channels ?? 0
    }
    if (canViewDashboard('settings')) {
      costPeriod.value = data.cost_period || 0
      costToday.value = data.cost_today || 0
      costMonth.value = data.cost_this_month || 0
      costByDay.value = data.cost_by_day || []
      exchangeRate.value = data.exchange_rate || 26000
    }
  } catch {
    if (requestId === dashboardRequestId && requestTenantId === tenantId.value) stats.value[1].value = '—'
  }
}

// Demo data state
const demoStatus = ref<{ has_data: boolean; is_demo: boolean } | null>(null)
const importingDemo = ref(false)
const resettingDemo = ref(false)
const resetDialog = ref(false)

async function loadDemoStatus(requestTenantId = tenantId.value) {
  const requestId = ++demoStatusRequestId
  try {
    const { data } = await api.get(`/tenants/${requestTenantId}/demo/status`)
    if (requestId !== demoStatusRequestId || requestTenantId !== tenantId.value) return
    demoStatus.value = data
  } catch { /* ignore */ }
}

async function importDemo() {
  importingDemo.value = true
  try {
    await api.post(`/tenants/${tenantId.value}/demo/import`)
    await loadDemoStatus()
    await loadDashboard()
  } catch (e: any) {
    alert(e.response?.data?.error || 'Import failed')
  } finally {
    importingDemo.value = false
  }
}

async function resetDemo() {
  resettingDemo.value = true
  try {
    await api.delete(`/tenants/${tenantId.value}/demo/reset`)
    resetDialog.value = false
    await loadDemoStatus()
    await loadDashboard()
  } catch (e: any) {
    alert(e.response?.data?.error || 'Reset failed')
  } finally {
    resettingDemo.value = false
  }
}

watch(tenantId, async (requestTenantId, _oldTenantId, onCleanup) => {
  const requestId = ++permissionRequestId
  dashboardRequestId++
  onCleanup(() => {
    if (permissionRequestId === requestId) permissionRequestId++
    dashboardRequestId++
  })
  dashboardPermissionsReady.value = false
  dashboardRole.value = ''
  dashboardPermissions.value = {}
  clearDashboardData()
  demoStatus.value = null
  if (!requestTenantId) return
  loadDemoStatus(requestTenantId)

  try {
    const { data } = await api.get(`/tenants/${requestTenantId}/me`)
    if (requestId !== permissionRequestId || requestTenantId !== tenantId.value) return
    dashboardRole.value = ['owner', 'admin', 'member'].includes(data.role) ? data.role : ''
    let permissions: Record<string, string> = {}
    if (dashboardRole.value && typeof data.permissions === 'string') {
      try {
        const parsed = JSON.parse(data.permissions)
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          for (const [key, value] of Object.entries(parsed)) {
            if (typeof value === 'string') permissions[key] = value
          }
        }
      } catch { /* malformed permission data fails closed */ }
    }
    dashboardPermissions.value = permissions
    dashboardPermissionsReady.value = true
    if (hasDashboardReadAccess()) loadDashboard()
  } catch {
    if (requestId !== permissionRequestId || requestTenantId !== tenantId.value) return
    dashboardRole.value = ''
    dashboardPermissions.value = {}
    dashboardPermissionsReady.value = true
  }
}, { immediate: true })

// CCMAI-UX-001a (UX-01): never negative; minutes, then hours, then days.
const { locale } = useI18n()
function timeAgo(dateStr: string) {
  return formatRelative(dateStr, locale.value as UiLocale)
}

function goToConversation(convId: string, tab?: string) {
  if (convId) {
    const query: Record<string, string> = { conv: convId }
    if (tab) query.tab = tab
    router.push({ path: `/${tenantId.value}/messages`, query })
  }
}
</script>
