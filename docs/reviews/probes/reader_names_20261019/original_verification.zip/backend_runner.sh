#!/bin/sh
export R101_MYSQL_DSN='ccma:r123-synthetic-only@tcp(ccma-r123-mysql-54bc229d:3306)/review_reader_names?charset=utf8mb4&parseTime=True&loc=UTC'
go test ./api/handlers -run '^(TestM3CaseParticipant|TestR101HumanWorkflowNative|TestR101SourceAndPermissionConflicts|TestM3ChangedSource)' -v -count=1 -timeout 10m > /tmp/native.log 2>&1
code=$?
cp /tmp/native.log /out/native.log
printf '%s\n' "$code" > /out/native.exit
if [ "$code" -ne 0 ]; then exit "$code"; fi
for count in $(seq 1 180); do
  if [ -f /out/frontend-build.exit ]; then break; fi
  sleep 1
done
if [ ! -f /out/frontend-build.exit ]; then exit 71; fi
if [ "$(cat /out/frontend-build.exit)" != 0 ]; then exit 72; fi
export R101_MYSQL_DSN='ccma:r123-synthetic-only@tcp(ccma-r123-mysql-54bc229d:3306)/review_m3_workflow?charset=utf8mb4&parseTime=True&loc=UTC'
export M3_WORKFLOW_BROWSER=1
export M3_WORKFLOW_DIRECTORY=/out/browser
export M3_WORKFLOW_FRONTEND=/web
go test ./api/handlers -run '^TestM3WorkflowBrowserFixture$' -v -count=1 -timeout 25m > /tmp/workflow.log 2>&1
code=$?
cp /tmp/workflow.log /out/browser/go-workflow.log
printf '%s\n' "$code" > /out/browser/go-workflow.exit
exit "$code"
